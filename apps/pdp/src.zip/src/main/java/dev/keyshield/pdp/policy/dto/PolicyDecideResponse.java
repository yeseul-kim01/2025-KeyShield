package dev.keyshield.pdp.policy.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Setter;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
public class PolicyDecideResponse {
    private String tenantId;
    private String userId;
    private String site;

    // allow | mask | block
    private String action;
    private String reason;

    // 서버가 최종 적용한 detectTypes (정책상 override 가능)
    private List<String> detectTypes;

    private RestrictedStatus restricted;

    @Data
    @Builder
    @Setter
    @AllArgsConstructor
    public static class RestrictedStatus {
        private boolean active;
        private String level;      // NONE | SOFT | HARD
        private long untilEpochMs; // 제한 종료 시각
        private double score;      // 누적 score
    }

    public PolicyDecideResponse() {

    }

}
